package matcher;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class OrderBookTest {

    static OrderBook orderBook;

    @Before
    public void init() {
        orderBook = new OrderBook();
    }

    @Test
    public void testCorrectSell() {
        orderBook.addOrderToOrderBook(Operation.BUY, Arrays.asList(10.0, 9.0));
        orderBook.addOrderToOrderBook(Operation.BUY, Arrays.asList(90.0, 55.0));
        orderBook.addOrderToOrderBook(Operation.BUY, Arrays.asList(20.0, 10.0));
        orderBook.addOrderToOrderBook(Operation.BUY, Arrays.asList(20.0, 1.0));
        orderBook.addOrderToOrderBook(Operation.BUY, Arrays.asList(25.0, 1.0));

        orderBook.printOrderBook();

        orderBook.addOrderToOrderBook(Operation.SELL, Arrays.asList(200.0, 2.0));

        orderBook.printOrderBook();
        Assert.assertEquals(Arrays.asList(80.0, 2.0), getBuyOrderQuantityPrice(2.0));
    }

    @Test
    public void testCorrectBuy() {
        orderBook.addOrderToOrderBook(Operation.SELL, Arrays.asList(10.0, 9.0));
        orderBook.addOrderToOrderBook(Operation.SELL, Arrays.asList(90.0, 55.0));
        orderBook.addOrderToOrderBook(Operation.SELL, Arrays.asList(20.0, 10.0));
        orderBook.addOrderToOrderBook(Operation.SELL, Arrays.asList(20.0, 160.0));

        orderBook.printOrderBook();

        orderBook.addOrderToOrderBook(Operation.BUY, Arrays.asList(200.0, 100.0));

        orderBook.printOrderBook();
        Assert.assertEquals(Arrays.asList(80.0, 100.0), getSellOrderQuantityPrice());
    }


    private List<Double> getSellOrderQuantityPrice() {
        double price;
        Node result = orderBook.getOrderTracker()
                               .findBetterBuy(new LinkedList<>(),
                                       orderBook.getOrderTracker().getRoot())
                               .get(0);

        return Arrays.asList(result.getOrderList().get(0).getQuantity(), result.getPrice());
    }

    private List<Double> getBuyOrderQuantityPrice(double price) {
        Double quantity = orderBook.getOrderTracker()
                                   .findBetterSell(new LinkedList<>(),
                                           orderBook.getOrderTracker().getRoot(), price)
                                   .stream()
                                   .map(Node::getOrderList)
                                   .findFirst()
                                   .map(k -> k.get(0))
                                   .map(Order::getQuantity)
                                   .orElse(null);

        return Arrays.asList(quantity, price);
    }
}