package matcher;

import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import static matcher.OrderMatcher.getOperation;
import static matcher.OrderMatcherUtil.interpretUserInput;

public class OrderMatcherTest {

    @Test
    public void testWrongOperationUserInput() {
        List<Double> result = interpretUserInput("hej 90@89");
        Assert.assertNull(result);
        Assert.assertEquals(Operation.INVALID, getOperation());
    }

    @Test
    public void testAllowSloppyInputBuy() {
        List<Double> result = interpretUserInput("buy 90@89");
        Assert.assertEquals(Arrays.asList(90.0, 89.0), result);
        Assert.assertEquals(Operation.BUY, getOperation());
    }

    @Test
    public void testAllowSloppyInputSell() {
        List<Double> result = interpretUserInput("seLl 90@@89");
        Assert.assertEquals(Arrays.asList(90.0, 89.0), result);
        Assert.assertEquals(Operation.SELL, getOperation());
    }

    @Test(expected = NullPointerException.class)
    public void testWrongInputNPE() {
        interpretUserInput(null);
    }
}