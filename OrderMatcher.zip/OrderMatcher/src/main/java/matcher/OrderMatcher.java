package matcher;

import java.util.List;
import java.util.Scanner;

import static java.lang.System.in;
import static java.lang.System.out;
import static matcher.Operation.EXIT;
import static matcher.OrderMatcherUtil.interpretUserInput;


public class OrderMatcher {

    static Operation operation;
    static OrderBook orderBook = new OrderBook();

    public static void main(String[] args) {
        out.println("Please enter an order. Allowed operations: " +
                    "\n BUY quantity@price" +
                    "\n SELL quantity@price" +
                    "\n PRINT" +
                    "\n EXIT");

        Scanner input = new Scanner(in);

        while (operation != EXIT) {
            List<Double> quantityAndPrice = interpretUserInput(input.nextLine());
            switch (operation) {
                case PRINT -> orderBook.printOrderBook();
                case BUY, SELL -> orderBook.addOrderToOrderBook(operation, quantityAndPrice);
                case INVALID -> out.print("An invalid option type, please try again. \n");
                default -> operation = EXIT;
            }
        }
        out.print("Exit");
        input.close();
    }

    public static void setOperation(Operation operation) {
        OrderMatcher.operation = operation;
    }

    public static Operation getOperation() {
        return OrderMatcher.operation;
    }
}
