package matcher;

import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.List;

import static java.lang.System.out;
import static matcher.OrderMatcher.setOperation;

public class OrderMatcherUtil {


    private OrderMatcherUtil() {
        throw new UnsupportedOperationException();
    }

    /**
     * Translate user input to operation as well quantity and price when applicable.
     *
     * @param userInput inputString
     * @return quantity and price
     */
    public static List<Double> interpretUserInput(String userInput) {
        List<Double> quantityAndPrice = null;
        try {
            List<String> inputList;
            if (!userInput.contains(" ")) {
                recogniseOperation(userInput.toUpperCase());
            } else {
                inputList = Arrays.stream(userInput.split(" "))
                                  .filter(k -> !k.isBlank())
                                  .toList();

                if (inputList.size() > 2 || inputList.isEmpty()) {
                    out.print("To long input: \n" + inputList + "\n");
                    setOperation(Operation.INVALID);
                } else {
                    String operationInput = inputList.get(0).toUpperCase();
                    if (inputList.size() > 1) {
                        String priceQuantityInput = inputList.get(1);
                        quantityAndPrice = recogniseOperation(operationInput, priceQuantityInput);
                    } else {
                        recogniseOperation(userInput.toUpperCase());
                    }
                }
            }

        } catch (InputMismatchException e) {
            throw new InputMismatchException("Invalid input. Please try one more time.");
        } catch (NullPointerException e) {
            throw new NullPointerException("Input cannot be empty. Please try one more time.");
        }

        return quantityAndPrice;
    }

    /**
     * Get quantity and price if operation is SELL or BUY
     *
     * @param operationInput operation to perform
     * @param quantityAndPriceInput quantity and price
     * @return
     */
    private static List<Double> recogniseOperation(String operationInput, String quantityAndPriceInput) {
        List<Double> quantityAndPrice = null;
        if (operationInput.equals(Operation.BUY.name())) {
            setOperation(Operation.BUY);
            quantityAndPrice = getQuantityAndPriceFromInput(quantityAndPriceInput);
        } else if (operationInput.equals(Operation.SELL.name())) {
            setOperation(Operation.SELL);
            quantityAndPrice = getQuantityAndPriceFromInput(quantityAndPriceInput);
        } else {
            recogniseOperation(operationInput);
        }
        return quantityAndPrice;
    }

    /**
     * Set operation based on user input
     *
     * @param operationInput operation
     */
    private static void recogniseOperation(String operationInput) {
        if (operationInput.equals(Operation.PRINT.name())) {
            setOperation(Operation.PRINT);
        } else if (operationInput.equals(Operation.EXIT.name())) {
            setOperation(Operation.EXIT);
        } else {
            setOperation(Operation.INVALID);
        }

    }

    /**
     * Read quantity and price from input.
     * @param input user input
     * @return quantity and price
     */
    protected static List<Double> getQuantityAndPriceFromInput(String input) {
        List<Double> quantityAndPrice = null;

        try {
            quantityAndPrice = Arrays.stream(input.split("@"))
                                     .filter(k -> !k.isBlank())
                                     .map(Double::valueOf)
                                     .filter(k -> k > 0)
                                     .toList();

            if (quantityAndPrice.size() != 2) {
                out.print("Incorrect quantity or price (must be numbers larger than 0): \n" + quantityAndPrice + "\n");
                setOperation(Operation.INVALID);
            }

        } catch (NumberFormatException e) {
            out.print("Quantity and price must be numbers: \n" + quantityAndPrice + "\n");
            setOperation(Operation.INVALID);
        }
        return quantityAndPrice;
    }

}
