package matcher;

import java.util.LinkedList;
import java.util.List;

import static java.lang.System.out;


public class OrderBook {

    OrderTree orderTracker;

    public OrderBook() {
        orderTracker = new OrderTree();
    }

    public void printOrderBook() {
        Node root = orderTracker.getRoot();

        out.print("--- BUY --- \n");
        orderTracker.printAllBuyOrders(root);

        out.print("--- SELL --- \n");
        orderTracker.printAllSellOrders(root);
    }

    /**
     * Add an order to orderTracker
     *
     * @param operation        operation
     * @param quantityAndPrice quantityAndPrice
     */
    public void addOrderToOrderBook(Operation operation, List<Double> quantityAndPrice) {
        orderTracker.add(operation, quantityAndPrice.get(0), quantityAndPrice.get(1));
    }

    public OrderTree getOrderTracker() {
        return orderTracker;
    }

}

class OrderTree {

    Node root;

    /**
     * Add new order to the order book
     *
     * @param operation operation
     * @param quantity  quantity
     * @param price     price
     */
    void add(Operation operation, double quantity, double price) {
        root = addRecursive(root, operation, quantity, price);
    }

    /**
     * Add and match orders in order book
     *
     * @param current   current node
     * @param operation operation of incoming order
     * @param quantity  quantity of incoming order
     * @param price     price of incoming order
     * @return node
     */
    private Node addRecursive(Node current, Operation operation, double quantity, double price) {
        if (current == null) {
            return new Node(operation, quantity, price);
        }

        if (price < current.getPrice()) {
            if (operation.equals(Operation.SELL) && current.getOperation().equals(Operation.BUY)) {
                current = matchOrder(current, operation, quantity, price);
            } else {
                current.left = addRecursive(current.left, operation, quantity, price);
            }
        } else if (price > current.getPrice()) {
            if (operation.equals(Operation.BUY) && current.getOperation().equals(Operation.SELL)) {
                current = matchOrder(current, operation, quantity, price);
            } else {
                current.right = addRecursive(current.right, operation, quantity, price);
            }
        } else {
            if (!operation.equals(current.getOperation())) {
                current = matchOrder(current, operation, quantity, price);
            } else {
                current.addNewOrder(operation, quantity);
            }
        }

        return current;
    }

    /**
     * Check if there exists more suitable buy order for trade
     *
     * @param current current node
     * @return boolean
     */
    private boolean checkIfExistsBetterBuy(Node current) {
        boolean betterBuy = false;
        while (current != null && !betterBuy) {
            if (current.getOperation().equals(Operation.BUY)) {
                betterBuy = true;
                break;
            } else {
                checkIfExistsBetterBuy(current.right);
                checkIfExistsBetterBuy(current.left);
            }
        }
        return betterBuy;
    }

    /**
     * Match orders in the order book if:
     * <li> There exists buy order at a higher price or equal to a sell order in the order book.
     * <li> There exists sell order at a lower price or equal to a buy order in the order book.
     *
     * @param current   current node
     * @param operation operation
     * @param quantity  incoming order's quantity
     * @param price     incoming order's price
     * @return node
     */
    private Node matchOrder(Node current, Operation operation, double quantity, double price) {

        if ((operation.equals(Operation.SELL) && current.right != null && checkIfExistsBetterBuy(current.right))) {

            if (!findBetterBuy(new LinkedList<>(), current).isEmpty()) {
                current = findBetterBuy(new LinkedList<>(), current).get(0);
            }

        } else if (operation.equals(Operation.BUY) && !findBetterSell(new LinkedList<>(), current, price).isEmpty()) {
            current = findBetterSell(new LinkedList<>(), current, price).get(0);
        }

        for (Order order : current.getOrderList()) {
            double orderQuantity = order.getQuantity();
            if (orderQuantity > quantity) {
                order.setQuantity(orderQuantity - quantity);
                printNewTrade(quantity, current.getPrice());
                quantity = 0.0;
                break;
            } else {
                printNewTrade(orderQuantity, current.getPrice());
                current.removeFromOrderList();
                quantity = quantity - orderQuantity;
            }
        }

        if (quantity > 0.0) {

            if (operation.equals(Operation.BUY)) {
                if (!findBetterSell(new LinkedList<>(), getRoot(), price).isEmpty()) {
                    return addRecursive(getRoot(), operation, quantity, price);
                }
                return addRecursiveWithoutMatch(getRoot(), operation, quantity, price);
            }

            if (getRoot() == null) {
                return new Node(operation, quantity, price);
            } else if (getRoot().getOrderList().isEmpty()) {
                return addRecursiveWithoutMatch(getRoot(), operation, quantity, price);
            }
            return addRecursive(getRoot(), operation, quantity, price);
        }

        if (current.getOrderList().isEmpty()) {
            current = null;
        }
        return current;
    }

    /**
     * A way of adding orders without matching them
     *
     * @param current   current node
     * @param operation operation
     * @param quantity  quantity
     * @param price     price
     * @return node
     */
    private Node addRecursiveWithoutMatch(Node current, Operation operation, double quantity, double price) {
        if (current == null) {
            return new Node(operation, quantity, price);
        }

        if (price < current.getPrice()) {
            current.left = addRecursiveWithoutMatch(current.left, operation, quantity, price);
        } else if (price > current.getPrice()) {
            current.right = addRecursiveWithoutMatch(current.right, operation, quantity, price);
        } else {
            current.addNewOrder(operation, quantity);
        }

        return current;
    }

    /**
     * Determine if there exists more suitable BUY order for trade
     *
     * @param nodeList node list
     * @param node     node
     * @return list of nodes
     */
    public List<Node> findBetterBuy(List<Node> nodeList, Node node) {
        if (node != null) {
            findBetterBuy(nodeList, node.right);
            if (!node.getOrderList().isEmpty() && node.getOrderList().get(0).getOperation().equals(Operation.BUY)) {
                nodeList.add(node);
            }
            findBetterBuy(nodeList, node.left);
        }
        return nodeList;
    }

    /**
     * Determine if there exists more suitable SELL order for trade
     *
     * @param nodeList node list
     * @param node     node
     * @return list of nodes
     */
    public List<Node> findBetterSell(List<Node> nodeList, Node node, double price) {
        if (node != null) {
            findBetterSell(nodeList, node.left, price);
            if (!node.getOrderList().isEmpty() &&
                node.getOrderList().get(0).getOperation().equals(Operation.SELL) &&
                price >= node.getPrice()) {
                nodeList.add(node);
            }
            findBetterSell(nodeList, node.right, price);
        }
        return nodeList;
    }

    /**
     * Print trade information
     *
     * @param quantity quantity
     * @param price    price
     */
    private void printNewTrade(double quantity, double price) {
        out.print("TRADE " + quantity + "@" + price + "\n");
    }

    /**
     * Print all sell orders in the order book
     *
     * @param node node
     */
    public void printAllSellOrders(Node node) {
        if (node != null) {
            printAllSellOrders(node.left);
            if (!node.getOrderList().isEmpty() &&
                node.getOrderList().get(0).getOperation().equals(Operation.SELL)) {
                node.printNode();
            }
            printAllSellOrders(node.right);
        }
    }

    /**
     * Print all buy orders in the order book
     *
     * @param node node
     */
    public void printAllBuyOrders(Node node) {
        if (node != null) {
            printAllBuyOrders(node.right);
            if (!node.getOrderList().isEmpty() && node.getOrderList().get(0).getOperation().equals(Operation.BUY)) {
                node.printNode();
            }
            printAllBuyOrders(node.left);
        }
    }

    public Node getRoot() {
        return root;
    }

}

class Node {
    List<Order> orderList = new LinkedList<>();
    Double price;
    Operation operation;
    Node left;
    Node right;

    Node(Operation operation, double quantity, double price) {
        this.orderList.add(new Order(operation, quantity));
        this.price = price;
        this.operation = operation;
        right = null;
        left = null;
    }

    public void printNode() {
        for (Order order : getOrderList()) {
            out.print(this.operation + " " + order.getQuantity() + "@" + this.price + "\n");
        }
    }

    public List<Order> getOrderList() {
        return orderList;
    }

    public void removeFromOrderList() {
        ((LinkedList<Order>) this.orderList).removeFirst();
    }

    public void addNewOrder(Operation operation, double quantity) {
        this.orderList.add(new Order(operation, quantity));
        setOperation(operation);
    }

    public void setOperation(Operation operation) {
        this.operation = operation;
    }

    public Operation getOperation() {
        return operation;
    }

    public double getPrice() {
        return price;
    }

}

