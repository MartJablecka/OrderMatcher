package matcher;

public enum Operation {
    BUY,
    SELL,
    PRINT,
    EXIT,
    INVALID;
}
