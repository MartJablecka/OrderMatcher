package matcher;

class Order {
    Operation operation;
    double quantity;

    Order(Operation operation, double quantity) {
        this.operation = operation;
        this.quantity = quantity;
    }

    public Operation getOperation() {
        return operation;
    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

}
